<?php

namespace App\Http\Controllers;

use App\Feedbacks;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;

class FeedbackController extends Controller
{

    //Success
    public $successStatus = 200;
    //Bad Request
    public $paramsEmptyStatus = 400;
    //Auth Error
    public $authErrorStatus = 401;

    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'feedback' => 'required|String',
            'device_id' => 'required|Integer',
        ]);

        //Request Error
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], $this->paramsEmptyStatus);
        }

        $filename="";
        $filepath="";

        if ($request->has('image')) {
            $filename = time().'.'.$request->image->extension();
            $request->image->move(public_path('uploads'), $filename);
            $filepath="uploads/".$filename;
        }

        $feedbackData=Feedbacks::create([
            "feedback"=>$request->feedback,
            "path"=>$filepath,
            "device_id"=>$request->device_id,
        ]);

        return response()->json([
            "token" => $feedbackData
        ], $this->successStatus);
    }

    public function drop(Request $request)
    {
        if ($request->has('id')) {
            $deviceData = Feedbacks::where('id', $request->id)->delete();
            return Response::json([
                    'data' => $deviceData
                ], $this->successStatus);
        } else {
            return Response::json([
                "code" => "0"
            ], $this->paramsEmptyStatus);
        }
    }

    public function get(Request $request)
    {
        if ($request->has('id')) {
            $deviceData = Feedbacks::where('device_id', $request->id)->get();
            return Response::json([
                    'data' => $deviceData
                ], $this->successStatus);
        } else {
            return Response::json([
                "code" => "0"
            ], $this->paramsEmptyStatus);
        }
    }
}
